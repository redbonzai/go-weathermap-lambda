package main

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/aws/aws-lambda-go/lambda"
	"net/http"
)

type WeatherRequest struct {
	Latitude  string `json:"latitude"`
	Longitude string `json:"longitude"`
}

type WeatherResponse struct {
	Condition   string `json:"condition"`
	Temperature string `json:"temperature"`
}

const openWeatherAPIKey = "YOUR_API_KEY_HERE"

func HandleLambdaEvent(ctx context.Context, event WeatherRequest) (*WeatherResponse, error) {
	weatherData, err := fetchWeatherData(event.Latitude, event.Longitude)
	if err != nil {
		return nil, err
	}
	return weatherData, nil
}

func fetchWeatherData(lat, lon string) (*WeatherResponse, error) {
	// Implement API call to OpenWeatherMap and parse response
	url := fmt.Sprintf("https://api.openweathermap.org/data/2.5/weather?lat=%s&lon=%s&appid=%s", lat, lon, openWeatherAPIKey)
	resp, err := http.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	// Parse JSON response, simplified for brevity
	var data struct {
		Main struct {
			Temp float64 `json:"temp"`
		} `json:"main"`
		Weather []struct {
			Main string `json:"main"`
		} `json:"weather"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&data); err != nil {
		return nil, err
	}

	// Simplified weather condition and temperature logic
	condition := "moderate"
	if len(data.Weather) > 0 {
		condition = data.Weather[0].Main
	}
	temperature := "moderate"
	tempCelsius := data.Main.Temp - 273.15 // Convert from Kelvin to Celsius
	if tempCelsius < 10 {
		temperature = "cold"
	} else if tempCelsius > 25 {
		temperature = "hot"
	}

	return &WeatherResponse{
		Condition:   condition,
		Temperature: temperature,
	}, nil
}

func main() {
	lambda.Start(HandleLambdaEvent)
}
